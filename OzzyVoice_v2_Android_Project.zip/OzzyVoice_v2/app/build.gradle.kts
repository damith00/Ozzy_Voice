plugins {
    id("com.android.application")
    kotlin("android")
}
android {
    namespace = "com.ozzyvoice"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.ozzyvoice"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
